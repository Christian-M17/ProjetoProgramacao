﻿namespace FormIdade
{
    partial class FormIdade
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblidade = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.txtidade = new System.Windows.Forms.TextBox();
            this.txtresultado = new System.Windows.Forms.TextBox();
            this.btnresultado = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblidade
            // 
            this.lblidade.AutoSize = true;
            this.lblidade.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblidade.Location = new System.Drawing.Point(12, 9);
            this.lblidade.Name = "lblidade";
            this.lblidade.Size = new System.Drawing.Size(198, 29);
            this.lblidade.TabIndex = 0;
            this.lblidade.Text = "Digite sua idade";
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblresultado.Location = new System.Drawing.Point(12, 204);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(176, 29);
            this.lblresultado.TabIndex = 1;
            this.lblresultado.Text = "Meses vividos";
            this.lblresultado.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtidade
            // 
            this.txtidade.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtidade.Location = new System.Drawing.Point(12, 41);
            this.txtidade.Name = "txtidade";
            this.txtidade.Size = new System.Drawing.Size(186, 39);
            this.txtidade.TabIndex = 2;
            this.txtidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtidade_KeyPress_1);
            // 
            // txtresultado
            // 
            this.txtresultado.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtresultado.Location = new System.Drawing.Point(12, 236);
            this.txtresultado.Name = "txtresultado";
            this.txtresultado.ReadOnly = true;
            this.txtresultado.Size = new System.Drawing.Size(186, 39);
            this.txtresultado.TabIndex = 3;
            // 
            // btnresultado
            // 
            this.btnresultado.BackColor = System.Drawing.Color.Lime;
            this.btnresultado.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnresultado.Location = new System.Drawing.Point(12, 115);
            this.btnresultado.Name = "btnresultado";
            this.btnresultado.Size = new System.Drawing.Size(129, 58);
            this.btnresultado.TabIndex = 4;
            this.btnresultado.Text = "Ver em meses";
            this.btnresultado.UseVisualStyleBackColor = false;
            this.btnresultado.Click += new System.EventHandler(this.btnresultado_Click);
            // 
            // FormIdade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnresultado);
            this.Controls.Add(this.txtresultado);
            this.Controls.Add(this.txtidade);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.lblidade);
            this.Name = "FormIdade";
            this.Text = "Idade";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblidade;
        private Label lblresultado;
        private TextBox txtidade;
        private TextBox txtresultado;
        private Button btnresultado;
    }
}