﻿namespace AppDecisoes
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirForm1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirForm2 = new System.Windows.Forms.ToolStripMenuItem();
            this.lblFred = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirForm1,
            this.exibirForm2});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirForm1
            // 
            this.exibirForm1.Image = global::AppDecisoes.Properties.Resources.Makoto_icon;
            this.exibirForm1.Name = "exibirForm1";
            this.exibirForm1.Size = new System.Drawing.Size(180, 22);
            this.exibirForm1.Text = "Form1";
            this.exibirForm1.Click += new System.EventHandler(this.exibirForm1_Click);
            // 
            // exibirForm2
            // 
            this.exibirForm2.Image = global::AppDecisoes.Properties.Resources.fred;
            this.exibirForm2.Name = "exibirForm2";
            this.exibirForm2.Size = new System.Drawing.Size(180, 22);
            this.exibirForm2.Text = "Form2";
            this.exibirForm2.Click += new System.EventHandler(this.exibirForm2_Click);
            // 
            // lblFred
            // 
            this.lblFred.AutoSize = true;
            this.lblFred.BackColor = System.Drawing.Color.Transparent;
            this.lblFred.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFred.ForeColor = System.Drawing.Color.Gold;
            this.lblFred.Location = new System.Drawing.Point(135, 347);
            this.lblFred.Name = "lblFred";
            this.lblFred.Size = new System.Drawing.Size(583, 73);
            this.lblFred.TabIndex = 2;
            this.lblFred.Text = "O Fred vai te pegar";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AppDecisoes.Properties.Resources.fred1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblFred);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirForm1;
        private System.Windows.Forms.ToolStripMenuItem exibirForm2;
        private System.Windows.Forms.Label lblFred;
    }
}