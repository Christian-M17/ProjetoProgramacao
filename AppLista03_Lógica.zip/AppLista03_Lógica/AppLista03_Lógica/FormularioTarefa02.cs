﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Lógica
{
    public partial class FormularioTarefa02 : Form
    {
        public FormularioTarefa02()
        {
            InitializeComponent();
        }
    }
}
