﻿using System;

using System.Windows.Forms;

namespace AppLista03_Lógica
{
    public partial class FormularioTarefa01 : Form
    {
        public FormularioTarefa01()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblnum1_Click(object sender, EventArgs e)
        {

        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            //soma e resultado
            float num1 = float.Parse(txtnum1.Text);
            float num3 = float.Parse(txtnum3.Text);
            float resultado;
            resultado = num1 + num3;

            //Mostrar resultado
            MessageBox.Show("Soma=" + resultado);
        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
            //Calcular Média
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float resultado;
            resultado = (num1 + num2 + num3) / 3;

            //Mostrar Resultado
            MessageBox.Show("Média=" + resultado);
          
        }

        private void btnporcentagem_Click(object sender, EventArgs e)
        {
            //Calcular Porcentagem
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float resultado;
            resultado= num1/(num1+ num2 + num3)*100;

            //Mostrar Resultado
            MessageBox.Show("Porcentagem=" + resultado + "%");
        }
    }
}
